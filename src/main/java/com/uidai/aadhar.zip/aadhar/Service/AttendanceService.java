package com.uidai.aadhar.Service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.uidai.aadhar.DTO.AttendanceRequestDTO;

public interface AttendanceService {

	public ResponseEntity<?> attendance(AttendanceRequestDTO request);
	public ResponseEntity<?> viewReport();
	public ResponseEntity<?> mobAttendance(AttendanceRequestDTO request);
}