package com.uidai.aadhar.Service;

import org.springframework.http.ResponseEntity;

public interface DashBoardService {
	
	public ResponseEntity<?> dashData();
	public ResponseEntity<?> loginInfo(String username);

}
