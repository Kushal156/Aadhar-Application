package com.uidai.aadhar.Security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
//import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
//@EnableMethodSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

	@Autowired
    private JwtFilter jwtFilter;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

    	//kushal code 
//        http
//            .csrf(csrf -> csrf.disable())
//            .authorizeHttpRequests(auth -> auth
//                .requestMatchers("/api/auth/**").permitAll()
//                .anyRequest().authenticated()
//            )
//            .sessionManagement(sess ->
//                sess.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
//            );
    	
    	//kishan code
    	http
        .csrf().disable()
        .authorizeRequests()
            .antMatchers("/api/auth/**").permitAll()
            .antMatchers("/attendance/punch", "/attendance/**").permitAll()
            .antMatchers("/file-upload/EOD").permitAll()
            .antMatchers("/operator/**", "/operator/new").permitAll()
            .antMatchers("/operator/specific-info").permitAll()
            .antMatchers("/dashboard/**").permitAll()
            .antMatchers("/device/**", "/center/**", "/api/enrolment/**", "/attendance/**").permitAll()
            .antMatchers("/alert/**").permitAll()
            .antMatchers("/center/**", "/center/view/**", "/center/view").permitAll()
            .anyRequest().authenticated()
        .and()
        .sessionManagement()
            .sessionCreationPolicy(SessionCreationPolicy.STATELESS);

        http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }
}
