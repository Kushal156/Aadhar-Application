package com.uidai.aadhar.ServiceImpl;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.uidai.aadhar.Entity.UidaiOperatorMasterEntity;

@Service
public class OpertorSpecification {

	public static Specification<UidaiOperatorMasterEntity> search(String keyword) {
        return (root, query, cb) -> {
            if (keyword == null || keyword.trim().isEmpty()) {
                return null;
            }

            String like = "%" + keyword.toLowerCase() + "%";

            return cb.or(
                    cb.like(cb.lower(root.get("operatorName")), like),
                    cb.like(cb.lower(cb.toString(root.get("aadharNo"))), like),
                    cb.like(cb.lower(cb.toString(root.get("panNo"))), like),
                    cb.like(cb.lower(root.get("operatorId")), like)
            );
        };
    }

    public static Specification<UidaiOperatorMasterEntity> hasStatus(Integer status) {
        return (root, query, cb) -> {
            if (status == null) {
                return null;
            }
            return cb.equal(root.get("isActive"), status);
        };
    }
    
    public static Specification<UidaiOperatorMasterEntity> hasAgencyCode(String agencyCode) {
        return (root, query, cb) -> {
            if (agencyCode == null || agencyCode.trim().isEmpty()) {
                return null;
            }
            return cb.equal(root.get("agencyCode"), agencyCode);
        };
    }
}
