package com.uidai.aadhar.ServiceImpl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.uidai.aadhar.DTO.AttendanceRequestDTO;
import com.uidai.aadhar.Entity.AttendanceEntity;
import com.uidai.aadhar.Repository.AttendanceRepository;
import com.uidai.aadhar.Service.AttendanceService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AttendanceServiceImpl implements AttendanceService {

	@Autowired
	AttendanceRepository repo;

	@Override
	public ResponseEntity<?> attendance(AttendanceRequestDTO request) {
		log.info("Attendance Request :: {}", request.toString());
		String status = repo.spSaveUidaiAttendance(request.getOperatorId(), request.getDeviceMacAddress());
		log.info("SP Result :: {}", status);
		return new ResponseEntity(status, HttpStatus.OK);
	}
	
	@Override
	public ResponseEntity<?> viewReport() {
		
		List<AttendanceEntity> data =  repo.findAll();
		log.info("data for attendance :: {}", data.toString());
		
		return new ResponseEntity(data, HttpStatus.OK);
	}
	
	@Override
	public ResponseEntity<?> mobAttendance(AttendanceRequestDTO request) {
		
		Map<String, Object> response = new LinkedHashMap();
		log.info("Attendance Request :: {}", request.toString());
		String status = repo.spSaveUidaiAttendance(request.getOperatorId(), request.getDeviceMacAddress());
		log.info("SP Result :: {}", status);
		
		if("in".equalsIgnoreCase(status)) {
			response.put("status", true);
			response.put("punchStatus", status);
			response.put("message", "Punched in successfully");
		} else if("out".equalsIgnoreCase(status)) {
			response.put("status", true);
			response.put("punchStatus", status);
			response.put("message", "Punched out successfully");
		}
		return new ResponseEntity(response, HttpStatus.OK);
	}

}